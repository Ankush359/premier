/* AI पोस्टर स्टुडिओ + जाहिरात (श्री. मन्नालाल गुप्ता विद्यालय). Admin: बनवा/प्रकाशित. सर्वांसाठी: popup + जाहिरात विभाग. */
(function () {
  'use strict';
  var W = 1080, H = 1350, SCH = 'श्री. मन्नालाल गुप्ता विद्यालय', PLACE = 'चांदूर रेल्वे, जि. अमरावती', LSK = 'mg-posters-v1';
  var TH = { royal: ['#0b1f4d', '#1b5fd0', '#f6c453'], sunrise: ['#9a2a06', '#f39a1e', '#fff1a8'], forest: ['#064e3b', '#16a34a', '#fde68a'], berry: ['#4c1d95', '#c026d3', '#fde68a'], ocean: ['#0c4a6e', '#06b6d4', '#fef08a'], ruby: ['#7f1d1d', '#ef4444', '#fde68a'] };
  var THN = { royal: 'निळा', sunrise: 'केशरी', forest: 'हिरवा', berry: 'जांभळा', ocean: 'समुद्र', ruby: 'लाल' };
  var EM = { book: '📚', star: '⭐', trophy: '🏆', cap: '🎓', sport: '⚽', palette: '🎨', megaphone: '📣', bell: '🔔', calendar: '📅', health: '🩺', computer: '💻', flag: '🇮🇳', music: '🎵', science: '🔬' };
  var LAY = ['hero', 'card', 'burst'], FH = '"Baloo 2","Mukta","Noto Sans Devanagari",sans-serif', FB = '"Mukta","Noto Sans Devanagari",sans-serif', FE = '"Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  function toast(m) { var e = $('#pgToast'); if (e) { e.textContent = m; e.classList.add('on', 'show'); setTimeout(function () { e.classList.remove('on', 'show'); }, 2600); } else alert(m); }

  /* ---------- poster renderer (canvas) ---------- */
  var embImg = null;
  function emblem() {
    if (embImg) return embImg;
    embImg = new Promise(function (res) {
      var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="48" fill="#fff" stroke="#f39a1e" stroke-width="3"/><circle cx="50" cy="50" r="40" fill="#fff" stroke="#0f2a55" stroke-width="2"/><path d="M50 14c6 8 9 12 5 19-2 4-8 4-10 0-3-6 1-10 5-19z" fill="#f39a1e"/><path d="M50 22c3 4 4 6 2 9-1 2-4 2-5 0-1-3 1-5 3-9z" fill="#e8501c"/><path d="M22 42c10-3 20-2 28 4 8-6 18-7 28-4v28c-10-3-20-2-28 4-8-6-18-7-28-4z" fill="#f6c453" stroke="#0f2a55" stroke-width="2"/><path d="M50 46v28" stroke="#0f2a55" stroke-width="2"/><path d="M14 74h72l-6 10H20z" fill="#0f2a55"/></svg>';
      var i = new Image(); i.onload = function () { res(i); }; i.onerror = function () { res(null); }; i.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    });
    return embImg;
  }
  function fontsReady() { try { return Promise.all([document.fonts.load('800 60px "Baloo 2"'), document.fonts.load('700 40px "Mukta"'), document.fonts.load('60px "Segoe UI Emoji"')]).catch(function () { }); } catch (e) { return Promise.resolve(); } }
  function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function wrap(c, text, maxW) { var w = String(text).split(' '), L = [], cur = ''; w.forEach(function (t) { var n = cur ? cur + ' ' + t : t; if (c.measureText(n).width > maxW && cur) { L.push(cur); cur = t; } else cur = n; }); if (cur) L.push(cur); return L; }
  function fit(c, text, maxW, maxL, start, min, wt, fam) { var s = start, L; for (; s >= min; s -= 4) { c.font = wt + ' ' + s + 'px ' + fam; L = wrap(c, text, maxW); if (L.length <= maxL && L.every(function (l) { return c.measureText(l).width <= maxW; })) return { s: s, L: L }; } c.font = wt + ' ' + min + 'px ' + fam; return { s: min, L: wrap(c, text, maxW).slice(0, maxL) }; }
  function lines(c, L, x, y, lh, al) { c.textAlign = al || 'center'; L.forEach(function (l, i) { c.fillText(l, x, y + i * lh); }); return y + L.length * lh; }
  function bg(c, th) {
    var g = c.createLinearGradient(0, 0, W, H); g.addColorStop(0, th[0]); g.addColorStop(1, th[1]); c.fillStyle = g; c.fillRect(0, 0, W, H);
    c.fillStyle = 'rgba(255,255,255,.07)'; [[900, 200, 330], [120, 1000, 380], [980, 1150, 240]].forEach(function (a) { c.beginPath(); c.arc(a[0], a[1], a[2], 0, 7); c.fill(); });
    c.fillStyle = 'rgba(255,255,255,.12)'; for (var i = 0; i < 6; i++) for (var j = 0; j < 4; j++) { c.beginPath(); c.arc(760 + i * 44, 250 + j * 44, 4, 0, 7); c.fill(); }
    c.fillStyle = 'rgba(0,0,0,.14)'; c.beginPath(); c.moveTo(0, H - 260); c.quadraticCurveTo(W / 2, H - 340, W, H - 250); c.lineTo(W, H); c.lineTo(0, H); c.fill();
  }
  function head(c, em) {
    c.save(); c.shadowColor = 'rgba(0,0,0,.25)'; c.shadowBlur = 24; c.shadowOffsetY = 8; c.fillStyle = '#fff'; rr(c, 50, 46, W - 100, 124, 62); c.fill(); c.restore();
    if (em) c.drawImage(em, 64, 58, 100, 100);
    c.fillStyle = '#0f2a55'; c.textAlign = 'left'; c.font = '800 46px ' + FH; c.fillText(SCH, 184, 112); c.fillStyle = '#5b6b82'; c.font = '600 28px ' + FB; c.fillText(PLACE, 186, 150);
  }
  function foot(c, th, spec) {
    c.fillStyle = 'rgba(0,0,0,.28)'; c.fillRect(0, H - 96, W, 96); c.fillStyle = '#fff'; c.textAlign = 'center';
    c.font = '700 34px ' + FB; c.fillText(spec.phone ? '☎  संपर्क: ' + spec.phone : SCH + ' • ' + PLACE, W / 2, H - 38);
  }
  function cta(c, th, spec, y) {
    if (!spec.cta) return; c.save(); c.shadowColor = 'rgba(0,0,0,.3)'; c.shadowBlur = 24; c.shadowOffsetY = 10; c.fillStyle = th[2]; rr(c, 150, y, W - 300, 100, 50); c.fill(); c.restore();
    var f = fit(c, spec.cta + '  ➜', W - 380, 1, 48, 30, 800, FH); c.fillStyle = th[0]; c.font = '800 ' + f.s + 'px ' + FH; c.textAlign = 'center'; c.fillText(f.L[0], W / 2, y + 66);
  }
  function emoji(c, k, x, y, size) { c.font = size + 'px ' + FE; c.textAlign = 'center'; c.fillStyle = '#000'; c.fillText(EM[k] || '📣', x, y + size * .35); }
  function pts(c, th, spec, y, maxY, dark) {
    var P = (spec.points || []).slice(0, 4), gap = 14, h = 84; while (P.length) { h = Math.min(84, Math.floor((maxY - y) / P.length) - gap); if (h >= 62) break; P.pop(); }
    P.forEach(function (p, i) {
      var yy = y + i * (h + gap); c.fillStyle = dark ? 'rgba(15,42,85,.07)' : 'rgba(255,255,255,.16)'; rr(c, 90, yy, W - 180, h, 28); c.fill();
      c.fillStyle = th[2]; c.beginPath(); c.arc(146, yy + h / 2, 26, 0, 7); c.fill(); c.fillStyle = th[0]; c.font = '800 32px ' + FH; c.textAlign = 'center'; c.fillText('✓', 146, yy + h / 2 + 11);
      var f = fit(c, p, W - 340, 1, 38, 26, 700, FB); c.fillStyle = dark ? '#0f2a55' : '#fff'; c.font = '700 ' + f.s + 'px ' + FB; c.textAlign = 'left'; c.fillText(f.L[0], 196, yy + h / 2 + f.s * .33);
    });
    return y + P.length * (h + gap);
  }
  function tag(c, th, text, x, y, rot) {
    if (!text) return; c.save(); c.translate(x, y); c.rotate(rot || 0); c.font = '800 44px ' + FH; var w = c.measureText(text).width + 90;
    c.shadowColor = 'rgba(0,0,0,.3)'; c.shadowBlur = 16; c.shadowOffsetY = 6; c.fillStyle = th[2]; rr(c, -w / 2, -40, w, 80, 40); c.fill(); c.shadowColor = 'transparent';
    c.fillStyle = th[0]; c.textAlign = 'center'; c.fillText(text, 0, 15); c.restore();
  }
  var DRAW = {
    hero: function (c, th, s) {
      tag(c, th, s.tag, W / 2, 240, 0);
      c.fillStyle = 'rgba(255,255,255,.18)'; c.beginPath(); c.arc(W / 2, 400, 104, 0, 7); c.fill(); c.strokeStyle = th[2]; c.lineWidth = 6; c.stroke(); emoji(c, s.icon, W / 2, 400, 120);
      var f = fit(c, s.headline, W - 160, 3, 124, 60, 800, FH); c.fillStyle = '#fff'; c.font = '800 ' + f.s + 'px ' + FH; c.shadowColor = 'rgba(0,0,0,.35)'; c.shadowBlur = 14; c.shadowOffsetY = 5;
      var y = lines(c, f.L, W / 2, 580, f.s * 1.06); c.shadowColor = 'transparent';
      if (s.subhead) { var g = fit(c, s.subhead, W - 200, 2, 40, 28, 600, FB); c.fillStyle = th[2]; c.font = '600 ' + g.s + 'px ' + FB; y = lines(c, g.L, W / 2, y + 4, g.s * 1.3); }
      pts(c, th, s, y + 8, H - 250, false); cta(c, th, s, H - 232);
    },
    card: function (c, th, s) {
      c.save(); c.shadowColor = 'rgba(0,0,0,.3)'; c.shadowBlur = 40; c.shadowOffsetY = 16; c.fillStyle = '#fff'; rr(c, 60, 250, W - 120, 800, 44); c.fill(); c.restore();
      c.fillStyle = th[2]; rr(c, 60, 250, 22, 800, 11); c.fill(); tag(c, th, s.tag, 330, 250, -.05);
      c.fillStyle = th[1]; c.beginPath(); c.arc(W - 170, 300, 105, 0, 7); c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 8; c.stroke(); emoji(c, s.icon, W - 170, 300, 112);
      var f = fit(c, s.headline, 700, 3, 112, 56, 800, FH); c.fillStyle = th[0]; c.font = '800 ' + f.s + 'px ' + FH; var y = lines(c, f.L, 120, 430, f.s * 1.08, 'left');
      if (s.subhead) { var g = fit(c, s.subhead, W - 240, 2, 38, 26, 600, FB); c.fillStyle = '#4a5a78'; c.font = '600 ' + g.s + 'px ' + FB; y = lines(c, g.L, 120, y + 8, g.s * 1.3, 'left'); }
      pts(c, th, s, y + 20, 1030, true); cta(c, th, s, H - 232);
    },
    burst: function (c, th, s) {
      var cx = W / 2, cy = 410, n = 22; c.fillStyle = th[2]; c.beginPath(); for (var i = 0; i < n * 2; i++) { var r = i % 2 ? 170 : 220, a = Math.PI * i / n; c.lineTo(cx + r * Math.cos(a), cy + r * Math.sin(a)); } c.closePath(); c.shadowColor = 'rgba(0,0,0,.3)'; c.shadowBlur = 30; c.fill(); c.shadowColor = 'transparent';
      emoji(c, s.icon, cx, cy - 70, 88); var f = fit(c, s.tag || 'नवीन!', 300, 2, 70, 38, 800, FH); c.fillStyle = th[0]; c.font = '800 ' + f.s + 'px ' + FH; lines(c, f.L, cx, cy + 34, f.s * 1.05);
      var h = fit(c, s.headline, W - 160, 3, 108, 56, 800, FH); c.fillStyle = '#fff'; c.font = '800 ' + h.s + 'px ' + FH; c.shadowColor = 'rgba(0,0,0,.35)'; c.shadowBlur = 14; c.shadowOffsetY = 5; var y = lines(c, h.L, cx, 710, h.s * 1.06); c.shadowColor = 'transparent';
      if (s.subhead) { var g = fit(c, s.subhead, W - 200, 2, 38, 26, 600, FB); c.fillStyle = th[2]; c.font = '600 ' + g.s + 'px ' + FB; y = lines(c, g.L, cx, y + 2, g.s * 1.3); }
      pts(c, th, s, y + 8, H - 250, false); cta(c, th, s, H - 232);
    }
  };
  function render(spec, scale) {
    return Promise.all([fontsReady(), emblem()]).then(function (r) {
      var cv = document.createElement('canvas'); cv.width = W; cv.height = H; var c = cv.getContext('2d'), th = TH[spec.theme] || TH.royal; c.textBaseline = 'alphabetic';
      bg(c, th); head(c, r[1]); (DRAW[spec.layout] || DRAW.hero)(c, th, spec); foot(c, th, spec); return cv;
    });
  }
  window.MGPoster = { render: render };
  function localSpec(subject, details, phone) {
    var P = String(details || '').split(/\n|,|;/).map(function (x) { return x.trim(); }).filter(Boolean).slice(0, 4);
    return [0, 1, 2].map(function (i) { return { tag: 'सूचना', headline: subject, subhead: '', points: P, cta: 'आजच संपर्क करा', icon: ['megaphone', 'star', 'cap'][i], theme: ['royal', 'sunrise', 'forest'][i], layout: LAY[i], phone: phone }; });
  }

  /* ---------- storage: Firestore (सर्वांसाठी) किंवा localStorage (फक्त या डिव्हाइसवर) ---------- */
  function fdb() { try { return (window.firebase && firebase.apps && firebase.apps.length) ? firebase.firestore() : null; } catch (e) { return null; } }
  function localList() { try { return JSON.parse(localStorage.getItem(LSK)) || []; } catch (e) { return []; } }
  function localSave(a) { try { localStorage.setItem(LSK, JSON.stringify(a)); } catch (e) { } }
  function loadAll() {
    var d = fdb(), now = Date.now();
    var loc = localList().filter(function (p) { return p.exp > now; });
    if (!d) return Promise.resolve(loc);
    return d.collection('posters').orderBy('createdAt', 'desc').limit(12).get().then(function (q) {
      var a = []; q.forEach(function (x) { var v = x.data(); var e = v.expires && v.expires.toMillis ? v.expires.toMillis() : 0; if (e > now && v.spec) a.push({ id: x.id, spec: v.spec, exp: e, fb: 1 }); }); return a.concat(loc);
    }).catch(function () { return loc; });
  }
  function publish(spec, days) {
    var d = fdb(), exp = Date.now() + days * 864e5;
    if (d && window.firebase.auth().currentUser) return d.collection('posters').add({ spec: spec, expires: firebase.firestore.Timestamp.fromMillis(exp), createdAt: firebase.firestore.FieldValue.serverTimestamp() }).then(function () { return 'all'; });
    var a = localList(); a.unshift({ id: 'l' + Date.now(), spec: spec, exp: exp }); localSave(a.slice(0, 12)); return Promise.resolve('local');
  }
  function remove(p) { if (p.fb) return fdb().collection('posters').doc(p.id).delete(); localSave(localList().filter(function (x) { return x.id !== p.id; })); return Promise.resolve(); }
  var isAdmin = function () { return document.body.classList.contains('admin'); };

  /* ---------- CSS ---------- */
  var st = document.createElement('style'); st.textContent =
    '#pstBtn{position:fixed;left:18px;bottom:96px;z-index:90;display:none;background:linear-gradient(90deg,#7a3df0,#1b7be0);color:#fff;border:0;border-radius:999px;padding:12px 20px;font:700 16px/1 var(--head,sans-serif);box-shadow:0 10px 26px rgba(74,74,232,.45);cursor:pointer}body.admin #pstBtn{display:block}' +
    '.pst-ov{position:fixed;inset:0;z-index:2000;background:rgba(8,16,36,.72);backdrop-filter:blur(6px);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:18px}' +
    '.pst-box{background:#fff;color:#0f2a55;border-radius:24px;width:min(980px,100%);padding:22px;position:relative;box-shadow:0 30px 80px rgba(0,0,0,.4);font-family:var(--body,sans-serif)}.pst-box h3{font:800 24px var(--head,sans-serif);margin:0 40px 12px 0}' +
    '.pst-x{position:absolute;right:14px;top:12px;border:0;background:#eef3fb;width:38px;height:38px;border-radius:50%;font-size:22px;cursor:pointer;color:#0f2a55}' +
    '.pst-f{display:grid;gap:10px}.pst-f label{font-weight:700;font-size:15px;display:grid;gap:4px}.pst-f input,.pst-f textarea,.pst-f select{border:1.5px solid #cdd9ee;border-radius:12px;padding:11px 13px;font:inherit;font-size:16px;color:#0f2a55;background:#fff}' +
    '.pst-row{display:flex;gap:10px;flex-wrap:wrap}.pst-row>*{flex:1 1 180px}.pst-b{border:0;border-radius:999px;padding:13px 22px;font:700 17px var(--head,sans-serif);cursor:pointer;background:linear-gradient(90deg,#1b7be0,#7a3df0);color:#fff}.pst-b.alt{background:#eef3fb;color:#0f2a55}.pst-b.ok{background:linear-gradient(90deg,#16a34a,#0f8a3a)}.pst-b:disabled{opacity:.6}' +
    '.pst-vs{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:14px 0}.pst-vs canvas,.pst-pv canvas,.ads-c canvas,.pst-pop canvas{width:100%;height:auto;border-radius:14px;display:block}.pst-vs>div{border:3px solid transparent;border-radius:16px;cursor:pointer;padding:3px}.pst-vs>div.on{border-color:#1b7be0;box-shadow:0 8px 22px rgba(27,123,224,.35)}' +
    '.pst-ed{display:grid;grid-template-columns:minmax(0,320px) 1fr;gap:18px;margin-top:8px}.pst-msg{padding:10px 14px;border-radius:12px;background:#fff4e0;color:#7a4a00;font-weight:600;margin:8px 0}' +
    '#ads{padding:46px 0 10px;background:linear-gradient(180deg,#fff,#f4f9ff)}#ads .wrap{max-width:1200px;margin:0 auto;padding:0 20px}#ads h2{font:800 clamp(26px,3vw,38px) var(--head,sans-serif);color:#0f2a55;margin:0 0 4px}#ads p{color:#5b6b82;margin:0 0 18px}' +
    '.ads-s{display:flex;gap:18px;overflow-x:auto;scroll-snap-type:x mandatory;padding:6px 4px 22px}.ads-c{flex:0 0 min(300px,78vw);scroll-snap-align:start;position:relative;border-radius:18px;box-shadow:0 14px 34px rgba(15,42,85,.22);cursor:zoom-in;transition:.25s;background:#fff}.ads-c:hover{transform:translateY(-6px)}.ads-c .del{position:absolute;top:8px;right:8px;background:#e11d48;color:#fff;border:0;border-radius:50%;width:34px;height:34px;font-size:18px;cursor:pointer;display:none}body.admin .ads-c .del{display:block}' +
    '.pst-pop{background:#fff;border-radius:22px;padding:12px;position:relative;width:min(460px,92vw,calc(78vh*.8));box-shadow:0 30px 80px rgba(0,0,0,.5);animation:pstIn .45s}.pst-pop .bar{display:flex;gap:8px;margin-top:10px}.pst-pop .bar button{flex:1;border:0;border-radius:999px;padding:11px;font:700 15px var(--head,sans-serif);cursor:pointer;background:#eef3fb;color:#0f2a55}.pst-pop .bar button.p{background:linear-gradient(90deg,#1b7be0,#7a3df0);color:#fff}@keyframes pstIn{from{opacity:0;transform:scale(.9) translateY(20px)}to{opacity:1;transform:none}}' +
    '@media(max-width:760px){.pst-ed{grid-template-columns:1fr}.pst-vs{grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}}';
  document.head.appendChild(st);

  /* ---------- helpers: download / share ---------- */
  function download(cv, name) { var a = document.createElement('a'); a.download = name || 'poster.png'; a.href = cv.toDataURL('image/png'); document.body.appendChild(a); a.click(); a.remove(); }
  function share(cv, text) {
    cv.toBlob(function (b) {
      var f = new File([b], 'poster.png', { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [f] })) navigator.share({ files: [f], text: text }).catch(function () { });
      else { download(cv); window.open('https://wa.me/?text=' + encodeURIComponent(text + ' ' + location.href.split('#')[0]), '_blank', 'noopener'); }
    });
  }
  function overlay(inner, cls) { var o = document.createElement('div'); o.className = 'pst-ov'; o.innerHTML = inner; document.body.appendChild(o); o.addEventListener('mousedown', function (e) { if (e.target === o) o.remove(); }); var x = o.querySelector('.pst-x'); if (x) x.onclick = function () { o.remove(); }; return o; }

  /* ---------- admin studio ---------- */
  function studio() {
    var V = [], sel = 0, cur = null;
    var o = overlay('<div class="pst-box"><button class="pst-x" aria-label="बंद">×</button><h3>🎨 AI पोस्टर स्टुडिओ</h3>' +
      '<div class="pst-f"><label>विषय (उदा. "नवीन प्रवेश सुरू", "वार्षिक स्नेहसंमेलन", "शिक्षक दिन शुभेच्छा")<input id="pSub" maxlength="200" placeholder="पोस्टरचा विषय लिहा"></label>' +
      '<label>तपशील (ऐच्छिक; तारीख, वर्ग, वेळ, ठिकाण… फक्त हेच पोस्टरवर येईल)<textarea id="pDet" rows="3" placeholder="उदा. इयत्ता ५ वी ते १० वी • प्रवेश सुरू • शेवटची तारीख ३० नोव्हेंबर"></textarea></label>' +
      '<div class="pst-row"><label>संपर्क फोन (ऐच्छिक)<input id="pPh" inputmode="tel" maxlength="40"></label><label>जाहिरात किती दिवस दिसेल?<select id="pDays"><option value="7">७ दिवस</option><option value="15" selected>१५ दिवस</option><option value="30">३० दिवस</option><option value="60">६० दिवस</option></select></label></div>' +
      '<div><button class="pst-b" id="pGo">✨ पोस्टर बनवा</button></div><div id="pMsg"></div></div><div id="pOut"></div></div>');
    var $o = function (s) { return o.querySelector(s); };
    function msg(t, bad) { $o('#pMsg').innerHTML = t ? '<div class="pst-msg"' + (bad ? '' : ' style="background:#e7f8ee;color:#0b6b32"') + '>' + esc(t) + '</div>' : ''; }
    function showVariants() {
      var out = $o('#pOut'); out.innerHTML = '<div class="pst-vs" id="pVs"></div><div class="pst-ed"><div class="pst-pv" id="pPv"></div><div class="pst-f" id="pEd"></div></div>';
      V.forEach(function (s, i) { var d = document.createElement('div'); d.onclick = function () { pick(i); }; out.querySelector('#pVs').appendChild(d); render(s).then(function (cv) { d.appendChild(cv); }); });
      pick(0);
    }
    function pick(i) {
      sel = i; cur = V[i]; var vs = $o('#pVs'); [].forEach.call(vs.children, function (d, k) { d.classList.toggle('on', k === i); });
      var th = Object.keys(TH).map(function (k) { return '<option value="' + k + '"' + (cur.theme === k ? ' selected' : '') + '>' + THN[k] + '</option>'; }).join('');
      var ly = LAY.map(function (k, j) { return '<option value="' + k + '"' + (cur.layout === k ? ' selected' : '') + '>' + ['पूर्ण पडदा', 'कार्ड', 'स्टार-बर्स्ट'][j] + '</option>'; }).join('');
      $o('#pEd').innerHTML = '<label>टॅग<input id="eTag" value="' + esc(cur.tag) + '"></label><label>मुख्य शीर्षक<input id="eHd" value="' + esc(cur.headline) + '"></label><label>उपशीर्षक<input id="eSh" value="' + esc(cur.subhead) + '"></label>' +
        '<label>मुद्दे (प्रत्येक ओळीत एक)<textarea id="ePt" rows="4">' + esc((cur.points || []).join('\n')) + '</textarea></label><label>बटण मजकूर<input id="eCt" value="' + esc(cur.cta) + '"></label>' +
        '<div class="pst-row"><label>रंग<select id="eTh">' + th + '</select></label><label>रचना<select id="eLy">' + ly + '</select></label></div>' +
        '<div class="pst-row"><button class="pst-b ok" id="bPub">📢 मुख्य साईटवर प्रकाशित करा</button><button class="pst-b alt" id="bDl">⬇ PNG</button><button class="pst-b alt" id="bSh">📲 शेअर</button></div>';
      var t; function redraw() { cur.tag = $o('#eTag').value; cur.headline = $o('#eHd').value || ' '; cur.subhead = $o('#eSh').value; cur.points = $o('#ePt').value.split('\n').map(function (x) { return x.trim(); }).filter(Boolean).slice(0, 5); cur.cta = $o('#eCt').value; cur.theme = $o('#eTh').value; cur.layout = $o('#eLy').value; clearTimeout(t); t = setTimeout(draw, 200); }
      ['#eTag', '#eHd', '#eSh', '#ePt', '#eCt', '#eTh', '#eLy'].forEach(function (s) { $o(s).addEventListener('input', redraw); });
      $o('#bDl').onclick = function () { render(cur).then(function (cv) { download(cv, 'mannalal-poster.png'); }); };
      $o('#bSh').onclick = function () { render(cur).then(function (cv) { share(cv, cur.headline + ' — ' + SCH); }); };
      $o('#bPub').onclick = function () {
        var b = this; b.disabled = true;
        publish(JSON.parse(JSON.stringify(cur)), +$o('#pDays').value).then(function (w) { toast(w === 'all' ? '✅ प्रकाशित झाले — आता सर्वांना दिसेल' : '✅ या डिव्हाइसवर प्रकाशित (सर्वांसाठी हवे असल्यास Firebase जोडा)'); o.remove(); showAds(true); }).catch(function (e) { b.disabled = false; msg('प्रकाशित करता आले नाही: ' + (e && e.message || e), true); });
      };
      draw();
    }
    function draw() { render(cur).then(function (cv) { var p = $o('#pPv'); p.innerHTML = ''; p.appendChild(cv); var th = $o('#pVs').children[sel]; if (th) { th.innerHTML = ''; var c2 = document.createElement('canvas'); c2.width = cv.width; c2.height = cv.height; c2.getContext('2d').drawImage(cv, 0, 0); th.appendChild(c2); } }); }
    $o('#pGo').onclick = function () {
      var sub = $o('#pSub').value.trim(); if (!sub) { msg('आधी विषय लिहा.', true); return; }
      var det = $o('#pDet').value, ph = $o('#pPh').value.trim(), b = this; b.disabled = true; b.textContent = '⏳ AI पोस्टर बनवत आहे…'; msg('');
      var go = window.firebase && firebase.apps && firebase.apps.length && firebase.auth().currentUser ? firebase.auth().currentUser.getIdToken() : Promise.resolve(null);
      go.then(function (tok) {
        if (!tok) throw new Error('NOAUTH');
        return fetch('/.netlify/functions/poster', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok }, body: JSON.stringify({ subject: sub, details: det }) }).then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || 'AI त्रुटी'); return j; }); });
      }).then(function (j) { V = j.variants.map(function (v) { v.phone = ph; return v; }); showVariants(); msg('✅ ३ पोस्टर तयार. आवडते निवडा, हवे तर मजकूर बदला व प्रकाशित करा.'); })
        .catch(function (e) {
          V = localSpec(sub, det, ph); showVariants();
          msg((e.message === 'NOAUTH' ? 'AI साठी Firebase प्रशासक लॉगिन हवे.' : e.message) + ' — सध्या साध्या टेम्पलेटवरून पोस्टर बनवले आहे; मजकूर खाली बदलता येतो.', true);
        }).then(function () { b.disabled = false; b.textContent = '✨ पुन्हा बनवा'; });
    };
  }

  /* ---------- public ads ---------- */
  var seenKey = 'mg-posters-seen';
  function seen() { try { return JSON.parse(sessionStorage.getItem(seenKey)) || []; } catch (e) { return []; } }
  function zoom(p) {
    render(p.spec).then(function (cv) {
      var o = overlay('<div class="pst-pop"><button class="pst-x" aria-label="बंद">×</button><div id="pc"></div><div class="bar"><button class="p" id="pd">⬇ डाउनलोड</button><button id="ps">📲 शेअर</button></div></div>'); o.style.alignItems = 'center';
      o.querySelector('#pc').appendChild(cv); o.querySelector('#pd').onclick = function () { download(cv); }; o.querySelector('#ps').onclick = function () { share(cv, p.spec.headline + ' — ' + SCH); };
    });
  }
  function showAds(noPop) {
    loadAll().then(function (list) {
      var sec = $('#ads'); if (!list.length) { if (sec) sec.remove(); return; }
      if (!sec) { sec = document.createElement('section'); sec.id = 'ads'; var tk = $('.ticker'); (tk ? tk.parentNode : document.body).insertBefore(sec, tk ? tk.nextSibling : null); }
      sec.innerHTML = '<div class="wrap"><h2>📣 शाळेची ताजी जाहिरात</h2><p>नवीन सूचना, प्रवेश व कार्यक्रम — पोस्टरवर क्लिक करून मोठे पहा व शेअर करा.</p><div class="ads-s"></div></div>';
      var box = sec.querySelector('.ads-s');
      list.forEach(function (p) {
        var d = document.createElement('div'); d.className = 'ads-c'; d.innerHTML = '<button class="del" title="काढा">×</button>'; box.appendChild(d);
        render(p.spec).then(function (cv) { d.insertBefore(cv, d.firstChild); });
        d.onclick = function (e) { if (e.target.className === 'del') { e.stopPropagation(); if (confirm('ही जाहिरात काढायची?')) remove(p).then(function () { showAds(true); }).catch(function () { toast('काढता आले नाही'); }); return; } zoom(p); };
      });
      if (!noPop) { var s = seen(), n = list.filter(function (p) { return s.indexOf(p.id) < 0; })[0]; if (n && !isAdmin()) setTimeout(function () { s.push(n.id); try { sessionStorage.setItem(seenKey, JSON.stringify(s)); } catch (e) { } zoom(n); }, 2800); }
    });
  }

  /* ---------- boot ---------- */
  var b = document.createElement('button'); b.id = 'pstBtn'; b.textContent = '🎨 AI पोस्टर'; b.onclick = studio; document.body.appendChild(b);
  var tries = 0, t0 = setInterval(function () { tries++; if (fdb() || tries > 12) { clearInterval(t0); showAds(false); } }, 500);
})();
