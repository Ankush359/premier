// AI पोस्टर: फक्त admin. विषयावरून पोस्टरचा मजकूर + डिझाइन (JSON) देतो; चित्र ब्राउझर काढतो (मराठी अक्षरे अचूक राहतात).
const { teacherClasses, J, parse, bearer } = require('./lib/fb');
const { gen } = require('./lib/gem');
const THEMES = ['royal', 'sunrise', 'forest', 'berry', 'ocean', 'ruby'];
const LAYOUTS = ['hero', 'card', 'burst'];
const ICONS = ['book', 'star', 'trophy', 'cap', 'sport', 'palette', 'megaphone', 'bell', 'calendar', 'health', 'computer', 'flag', 'music', 'science'];
const SYSTEM = 'तू श्री. मन्नालाल गुप्ता विद्यालय, चांदूर रेल्वे (श्री शिवाजी शिक्षण संस्था, अमरावती) साठी जाहिरात-पोस्टर लिहिणारा उत्कृष्ट मराठी कॉपीरायटर आहेस. ' +
  'दिलेल्या विषयावर ३ वेगवेगळे पोस्टर-प्रकार (variants) तयार कर. प्रत्येकासाठी: tag (२-४ शब्द, उदा. "प्रवेश सुरू!"), headline (३-६ शब्द, प्रभावी), subhead (एक ओळ, १२ शब्दांपर्यंत), points (३ ते ४ मुद्दे, प्रत्येक ६ शब्दांपर्यंत), cta (२-५ शब्द, उदा. "आजच संपर्क करा"), ' +
  'icon (' + ICONS.join('|') + ' पैकी एक), theme (' + THEMES.join('|') + ' पैकी एक), layout (' + LAYOUTS.join('|') + ' पैकी एक). ३ variants मध्ये वेगळे theme/layout व वेगळा सूर (उदा. आकर्षक / औपचारिक / उत्साही) ठेव. ' +
  'भाषा: विषय ज्या भाषेत असेल तीच (डिफॉल्ट मराठी). कठोर नियम: तारीख, शुल्क, फोन नंबर, पत्ता, निकाल, आकडे, सवलती फक्त "तपशील" मध्ये दिले असतील तरच वापर; ते नसतील तर स्वतः बनवू नकोस. शाळेबद्दल अतिशयोक्ती/खोटे दावे (नं. १, १००% इ.) लिहू नकोस. ' +
  'फक्त JSON दे: {"variants":[{"tag":"","headline":"","subhead":"","points":[""],"cta":"","icon":"","theme":"","layout":""}]}';
const cl = (s, n) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, n);
function clean(v, i) {
  if (!v || typeof v !== 'object') return null;
  const pts = (Array.isArray(v.points) ? v.points : []).map(x => cl(x, 60)).filter(Boolean).slice(0, 5);
  const o = { tag: cl(v.tag, 30), headline: cl(v.headline, 60), subhead: cl(v.subhead, 110), points: pts, cta: cl(v.cta, 40),
    icon: ICONS.includes(v.icon) ? v.icon : 'megaphone', theme: THEMES.includes(v.theme) ? v.theme : THEMES[i % THEMES.length], layout: LAYOUTS.includes(v.layout) ? v.layout : LAYOUTS[i % LAYOUTS.length] };
  return o.headline ? o : null;
}
function pick(text) {
  const t = String(text).replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  try { return JSON.parse(t); } catch (e) { const m = t.match(/\{[\s\S]*\}/); if (m) { try { return JSON.parse(m[0]); } catch (x) { } } return null; }
}
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return J(405, { error: 'POST हवे' });
  if (!process.env.GEMINI_API_KEY) return J(500, { error: 'AI अजून सुरू केलेला नाही (GEMINI_API_KEY नाही).' });
  const tok = bearer(event); if (!tok) return J(401, { error: 'प्रशासक म्हणून लॉगिन करा.' });
  let t; try { t = await teacherClasses(tok); } catch (e) { return J(500, { error: 'ओळख तपासणी चालली नाही.' }); }
  if (!t || !t.all) return J(403, { error: 'फक्त प्रशासकाला परवानगी आहे.' });
  const b = parse(event); const subject = cl(b && b.subject, 200); if (!subject) return J(400, { error: 'विषय लिहा.' });
  const details = String((b && b.details) || '').slice(0, 700);
  const r = await gen({ system: SYSTEM, parts: [{ text: 'विषय: ' + subject + '\nतपशील (हेच फक्त खरे मानायचे): ' + (details || 'काही दिलेले नाही') }], json: true, budgetMs: 9000 });
  if (r.limit) return J(429, { error: 'AI ची आजची मर्यादा संपली. थोड्या वेळाने प्रयत्न करा.' });
  if (r.timeout) return J(504, { error: 'AI ला वेळ लागला. पुन्हा प्रयत्न करा.' });
  if (!r.text) return J(502, { error: r.error || 'AI चे उत्तर मिळाले नाही.' });
  const o = pick(r.text); const arr = (o && (o.variants || (Array.isArray(o) ? o : [o]))) || [];
  const variants = arr.map(clean).filter(Boolean).slice(0, 3);
  if (!variants.length) return J(502, { error: 'AI चे उत्तर वाचता आले नाही. पुन्हा प्रयत्न करा.' });
  return J(200, { variants });
};
