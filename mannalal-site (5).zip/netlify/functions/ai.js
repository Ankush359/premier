// AI Teacher Assistant – Netlify Function (Gemini free tier)
// Key फक्त Netlify च्या Environment variables मध्ये ठेवा: GEMINI_API_KEY
const FB_API_KEY = process.env.FIREBASE_API_KEY || 'PASTE_API_KEY'; // public web key
const PROJECT = process.env.FIREBASE_PROJECT || 'PASTE_PROJECT_ID';
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'nitinkadu.1969@gmail.com').toLowerCase();
const MODELS = [process.env.GEMINI_MODEL, 'gemini-flash-latest', 'gemini-3.5-flash', 'gemini-2.5-flash'].filter(Boolean);

const hits = new Map(); // साधी मर्यादा: प्रति शिक्षक ताशी 30 विनंत्या
function limited(email) {
  const now = Date.now(), arr = (hits.get(email) || []).filter(t => now - t < 3600e3);
  if (arr.length >= 30) { hits.set(email, arr); return true; }
  arr.push(now); hits.set(email, arr); return false;
}
const J = (code, obj) => ({ statusCode: code, headers: { 'Content-Type': 'application/json; charset=utf-8' }, body: JSON.stringify(obj) });
const cut = (s, n) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, n);

async function verify(idToken) {
  const r = await fetch('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=' + FB_API_KEY, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ idToken })
  });
  if (!r.ok) return null;
  const j = await r.json(), u = j.users && j.users[0];
  return u && u.email ? u.email.toLowerCase() : null;
}
async function isTeacher(email, idToken) {
  if (email === ADMIN_EMAIL) return true;
  // शिक्षकाचे स्वतःचे खाते Firestore rules नुसारच वाचले जाते
  const r = await fetch('https://firestore.googleapis.com/v1/projects/' + PROJECT + '/databases/(default)/documents/teachers/' + encodeURIComponent(email),
    { headers: { Authorization: 'Bearer ' + idToken } });
  if (!r.ok) return false;
  const j = await r.json(), st = j.fields && j.fields.status && j.fields.status.stringValue;
  return !st || st === 'active';
}

const TYPES = {
  summary: 'पाठाचा सारांश: मुख्य मुद्दे, महत्त्वाच्या संकल्पना/शब्द आणि शेवटी 5 सोपे स्वाध्याय प्रश्न.',
  paper: 'प्रश्नपत्रिका: विभाग (अ, ब, क…), प्रत्येक प्रश्नाला गुण, एकूण गुण, वेळ आणि शेवटी उत्तरसूची/गुणदान सूचना.',
  mcq: 'बहुपर्यायी प्रश्न (MCQ): प्रत्येकाला (अ)(ब)(क)(ड) पर्याय, आणि शेवटी "उत्तरसूची" स्वतंत्रपणे.',
  practice: 'सराव प्रश्न: सोपे, मध्यम, कठीण अशा तीन गटांत, शेवटी उत्तरांचे मुद्दे.',
  worksheet: 'वर्कशीट: रिकाम्या जागा, जोड्या लावा, एका वाक्यात उत्तर, छोटे प्रश्न अशा विविध कृती; शेवटी उत्तरसूची.',
  plan: 'धड्याचे नियोजन: उद्दिष्टे, आवश्यक साहित्य, तासिकानुसार कृती (प्रस्तावना, सादरीकरण, सराव, मूल्यमापन), गृहपाठ.'
};

async function gemini(system, prompt) {
  let last = '';
  for (const m of MODELS) {
    const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + m + ':generateContent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.6, maxOutputTokens: 8192 }
      })
    });
    if (r.status === 429) return { limit: true };
    if (r.status === 404 || r.status === 400) { last = m + ': ' + r.status; continue; } // हे मॉडेल नाही → पुढचे
    if (!r.ok) { last = m + ': ' + r.status; continue; }
    const j = await r.json();
    const text = (((j.candidates || [])[0] || {}).content || {}).parts;
    const out = (text || []).map(p => p.text || '').join('').trim();
    if (out) return { text: out, model: m };
    last = m + ': रिकामे उत्तर';
  }
  return { error: last || 'कोणतेही मॉडेल चालले नाही' };
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return J(405, { error: 'POST हवे' });
  if (!process.env.GEMINI_API_KEY) return J(500, { error: 'GEMINI_API_KEY Netlify मध्ये जोडलेली नाही.' });
  const token = ((event.headers.authorization || event.headers.Authorization || '') + '').replace(/^Bearer\s+/i, '');
  if (!token) return J(401, { error: 'लॉगिन आवश्यक आहे.' });
  const email = await verify(token);
  if (!email) return J(401, { error: 'लॉगिन तपासता आले नाही. पुन्हा लॉगिन करा.' });
  if (!(await isTeacher(email, token))) return J(403, { error: 'हे खाते शिक्षक म्हणून सक्रिय नाही.' });
  if (limited(email)) return J(429, { error: 'ताशी मर्यादा संपली. थोड्या वेळाने पुन्हा प्रयत्न करा.' });

  let b; try { b = JSON.parse(event.body || '{}'); } catch (e) { return J(400, { error: 'चुकीची विनंती.' }); }
  const type = TYPES[b.type] ? b.type : 'summary';
  const cls = cut(b.cls, 40), subject = cut(b.subject, 60), topic = cut(b.topic, 200), extra = cut(b.extra, 600);
  const count = Math.min(Math.max(parseInt(b.count, 10) || 10, 1), 30);
  if (!topic) return J(400, { error: 'पाठ / विषय लिहा.' });

  const system = 'तू महाराष्ट्रातील शाळेच्या शिक्षकांना मदत करणारा सहाय्यक आहेस (राज्य मंडळ / बालभारती अभ्यासक्रम). ' +
    'उत्तर फक्त शुद्ध, सोप्या मराठीत दे. साधा मजकूर लिही: markdown चिन्हे (#, **, ```) वापरू नकोस; क्रमांक आणि ओळी वापर. ' +
    'वर्गाच्या स्तराला साजेशी भाषा ठेव. खात्री नसलेली तथ्ये, आकडे किंवा तारखा बनवू नकोस; शंका असेल तर "शिक्षकाने तपासावे" असे लिही. ' +
    'विद्यार्थ्यांची नावे किंवा वैयक्तिक माहिती कधीही लिहू नकोस. ' +
    'अभिवादन, प्रस्तावना किंवा "हा मजकूर तुम्ही वापरू शकता" असे शिक्षकाला उद्देशून कोणतेही वाक्य लिहू नकोस; थेट तयार मजकुरापासून सुरुवात कर, जो विद्यार्थ्यांना जसाच्या तसा देता येईल. प्रत्येक मुद्दा/प्रश्न वेगळ्या ओळीत लिही.';
  const prompt = 'वर्ग: ' + (cls || '—') + '\nविषय: ' + (subject || '—') + '\nपाठ / घटक: ' + topic + '\n' +
    'प्रश्नांची अंदाजे संख्या (लागू असल्यास): ' + count + '\n' + (extra ? 'अतिरिक्त सूचना: ' + extra + '\n' : '') +
    '\nतयार करायचे: ' + TYPES[type];

  try {
    const g = await gemini(system, prompt);
    if (g.limit) return J(429, { error: 'Gemini free मर्यादा संपली. काही मिनिटांनी (किंवा उद्या) पुन्हा प्रयत्न करा.' });
    if (g.error) return J(502, { error: 'AI सेवा चालली नाही (' + g.error + ').' });
    return J(200, { text: g.text, model: g.model });
  } catch (e) {
    return J(502, { error: 'AI सेवेशी संपर्क झाला नाही.' });
  }
};
